--DUDE, MAYBE MAKE ALL BLOCKS SHOULD BE INTEGERS
--also remember that flinch dir depends on the object hitting dir not necessarily the lr of the other person

--DUDE, MAYBE MAKE ALL BLOCKS SHOULD BE INTEGERS
--also remember that flinch dir depends on the object hitting dir not necessarily the lr of the other person

hitt = {}
hitt.me = {id = 1,
    x = 0,
    y = 0,
    width = 30,
    height = 60,
    v = 0,
    j = 0}

hitt.you = {id = 2,
    x = 0,
    y = 0,
    width = 30,
    height = 60,
    v = 0,
    j = 0}


--the big hit check
function hc(objx, objy, ojx2, objy2, id)
  hitt.me.x = me.x
  hitt.me.y = me.y

  hitt.you.x = you.x
  hitt.you.y = you.y

  for i,v in ipairs(hitt) do

    if id~=v.id and 
    (findxIntersect(objx,objy,objx2,objy2,v.x,v.y,v.x+v.v+v.width,v.y - v.j + v.height,true,true) or
      findxIntersect(objx,objy,objx2,objy2,v.x+v.width,v.y+v.height,v.x+v.v,v.y - v.j,true,true)or
      findxIntersect(objx,objy,objx2,objy2,v.x,v.y+v.height,v.x+v.v+v.width,v.y - v.j,true,true)or
      findxIntersect(objx,objy,objx2,objy2,v.x+v.width,v.y,v.x+v.v,v.y - v.j+v.height,true,true))
    then
      me.flinch = true
      me.ft = 100
end
end

end

