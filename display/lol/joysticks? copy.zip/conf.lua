function love.conf(t)
	t.window.width = 500
	t.window.height = 500
	t.title = "Game"


end