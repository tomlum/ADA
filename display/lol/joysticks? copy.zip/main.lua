

function love.load()
x = 10
y = 10
end
function love.update()

end

function love.draw()
	local joysticks = love.joystick.getJoysticks()
    for i, joystick in ipairs(joysticks) do
        love.graphics.print(joystick:getName(), 10, i * 20)
    end
end



