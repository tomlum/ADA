function love.conf(t)
	t.window.width = 1024
	t.window.height = 640
	t.title = "Game"


end