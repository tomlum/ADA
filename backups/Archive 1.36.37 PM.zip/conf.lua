function love.conf(t)
	t.window.width = 1024
	t.window.height = 700
	t.title = "Game"


end