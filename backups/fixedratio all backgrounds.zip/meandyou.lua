me = {}
	--boolean statuses
	me.g = true
	--the image
	me.im = love.graphics.newImage("me/walk/walk51.png")
	me.x = 5000
	me.xleft = me.x + 30
	me.xanimate = me.x
	me.mid = me.x / 2 + me.xleft / 2
	me.y = 1000 - 241 - 60
	me.feet = me.y + 60
	--the face/crest image
	me.leftface = false
	me.face = love.graphics.newImage("me/face/face1.png")
	me.facex = me.x + 12
	me.facedis = 2
	me.facey = me.feet - 54
	me.crest = love.graphics.newImage("me/crest/crest1.png")
	me.crestx = me.xanimate - 13
	me.cresty = me.y - 23
	--horizontal velocity
	me.v = 0
	--vertical velocity (j.ump)
	me.j = 0
	--on the ground?
	me.lr = 1




you = {}
	--boolean statuses
	you.g = true
	you.slide = false
	--the image
	you.im = love.graphics.newImage("me/idle/idle1.png")
	you.x = 5000
	you.xleft = you.x + 30
	you.mid = you.x / 2 + you.xleft / 2
	you.xanimate = you.xleft
	you.y = 1500 - 3 - 60
	you.feet = you.y + 60
	--the face/crest image
	you.leftface = true
	you.face = love.graphics.newImage("me/face/face1.png")
	you.facex = you.x + 12
	you.facedis = 2
	you.facey = you.feet - 54
	you.crest = love.graphics.newImage("me/crest/crest1.png")
	you.crestx = you.xanimate - 13
	you.cresty = you.y + 27
	you.slowdown = false
	--horizontal velocity
	you.v = 0
	--vertical velocity (j.ump) and jump time (jt) and hang time (ht)
	you.j = 0
	you.jt = 0
	you.ht = 0
	you.firstjump = true
	
	you.feet = you.y + 60
	you.lr = -1
	you.landing = false
	you.landingcounter = 0


enviro = {}
	enviro.floor = love.graphics.newImage("enviro/astreet.png")
	enviro.paralax = love.graphics.newImage("enviro/paralax.png")
	enviro.sky = love.graphics.newImage("enviro/sky.png")
	enviro.leftwall = 0
	enviro.rightwall = 7000