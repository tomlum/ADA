
idle1 = love.graphics.newImage("me/idle/idle1.png")
idle2 = love.graphics.newImage("me/idle/idle2.png")
walk1 = love.graphics.newImage("me/walk/walk51.png")
walk2 = love.graphics.newImage("me/walk/walk52.png")
walk3 = love.graphics.newImage("me/walk/walk53.png")
walk4 = love.graphics.newImage("me/walk/walk54.png")
walk5 = love.graphics.newImage("me/walk/walk55.png")
slide = love.graphics.newImage("me/walk/slide.png")
jumprise = love.graphics.newImage("me/jump/jumprise.png")
jumpfalling = love.graphics.newImage("me/jump/jumpfalling.png")
landing = love.graphics.newImage("me/jump/landing.png")
slowdown = love.graphics.newImage("me/jump/slowdown.png")
arm = love.graphics.newImage("me/jump/arm.png")

righty = you.v >= 0
lefty = you.v <= 0
rightme = me.v >= 0
leftme = me.v <= 0



--camera movement
cammovement = function ()
	if you.mid < 257
	then 
		camera2.xfollow = false
	elseif you.mid > 6750
	then camera2.xfollow = false
	else camera2.xfollow = true
	end
	if you.y >= floor - 241
		then
		camera2.yfollow = false
		camera2.y = floor - 510
	elseif you.y < 259
		then
		camera2.yfollow = false
	else
		camera2.yfollow=true
end
end


--function that adjusts the x for flipping left and right
meyoux = function ()
	me.xleft = me.x + 15
	me.mid = me.x / 2 + me.xleft / 2
	you.xleft = you.x + 30
	you.mid = you.x + 15

	if lefty
	then you.xanimate = you.xleft
		 you.leftface = true
	elseif righty
	then you.xanimate = you.x
		 you.leftface = false
	end
	

	if leftme
	then me.xanimate = me.xleft
		me.leftface = true
	elseif rightme 
	then me.xanimate = me.x
		me.leftface = false
	end

end

idelybla = 0
walktimery = 0

orient = function ()
	righty = you.v > 0
	lefty = you.v < 0
	rightme = me.v > 0
	leftme = me.v < 0
	if lefty
	then 
	leftyface = true
	you.lr = -1
	elseif righty
	then you.lr = 1
		end
	if leftme 
	then me.lr = -1
	elseif righty
	then me.lr = 1
		end
end

idley = function ()
	if idelybla < 17 then 
		you.im = idle1
		idelybla = idelybla + 1
	elseif idelybla >= 17 and idelybla < 33 then
		you.im = idle2
		idelybla = idelybla + 1
	elseif idelybla >=33 then
		idelybla = 0
	end
end

walky = function ()
	if walktimery < 7 then 
		you.im = walk1
		walktimery = walktimery + 1
	elseif walktimery >= 7 and walktimery < 14 then
		you.im = walk2
		walktimery = walktimery + 1
	elseif walktimery >= 14 and walktimery < 21 then
		you.im = walk3
		walktimery = walktimery + 1
	elseif walktimery >= 21 and walktimery < 28 then
		you.im = walk4
		walktimery = walktimery + 1
	elseif walktimery >= 28 and walktimery < 35 then
		you.im = walk5
		walktimery = walktimery + 1
	else
		walktimery = 0
	end
end

jumpey = function ()
	if you.j > 0 then 
		you.im = jumprise
	else you.im = jumpfalling
end
end

landycheck = function ()
	if you.landingcounter <= 0	
	then you.landing = false
	else
	you.landingcounter = you.landingcounter - 1

end
end

slidetimery = 0

slideycheck = function ()
	if slidetimery < 6
	then 
	slidetimery = slidetimery + 1
	elseif slidetimery >= 6
	then you.slide = false
		
	end
end



animatey = function ()
	landycheck()
	slideycheck()
	if you.slide 
	then you.im = slide

	elseif you.slowdown
	then you.im = slowdown

	elseif you.landing
	then you.im = landing

	elseif you.g and you.v == 0 and not you.slide 
	then idley()
	walktimery = 0

	elseif not you.g
	then
	jumpey()

	else
		walky()

	end
end

--function that draws the face at distance from midpoint
--facedis = function (x)
--	if lefty then facedis = 

--can add me
facemovement = function ()
	if you.slide
	then you.facedis = 1
	elseif you.landing
	then you.facedis = 5
	else you.facedis = 2
	end


	if you.leftface
	then you.facex = you.mid - you.facedis - 4  
	else you.facex = you.mid + you.facedis - 6
	end

	if you.im == idle1
	then  
	you.facey = you.feet - 54
	elseif you.im == idle2
	then 
	you.facey = you.feet - 53

	elseif you.landing
	then you.facey = you.feet - 42
	
	elseif you.j > 0 then you.facey = you.feet - 56
	elseif you.j < 0 then you.facey = you.feet - 53
	else you.facey = you.feet - 54
	end
end

--crestmovement = function ()
--	if 

--can add me
armanimate = function ()
	if you.slowdown and you.leftface
	then 
	love.graphics.draw(arm, you.x + 21, you.y + 20)
	elseif you.slowdown and not you.leftface
	then
	love.graphics.draw(arm, you.xleft - 21, you.y + 20, 0, -1, 1)
	end
end


crestmovement = function ()


	if you.landing
	then 
		if you.leftface
		then you.crestx = you.mid - 2
		else
		you.crestx = you.mid - 1
		end


	else 
		if you.leftface
		then you.crestx = you.mid - 1
		else you.crestx = you.mid - 2
		end
	end

	if you.landing
	then you.cresty = you.y + 37
	elseif you.im == idle2 
	then you.cresty = you.y + 28
	else you.cresty = you.y + 27
	end
end



			