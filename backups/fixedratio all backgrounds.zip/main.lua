require "camera"
require "meandyou"
require "FIZIX"
require "Animation"

function love.load()

end

function love.update()

moveme()

moveyou()

you.y = you.y - you.j
me.y = me.y - me.j
you.x = you.x + you.v
me.x = me.x + me.v


cammovement()


walls()

animatey()

orient()

meyoux()

you.feet = you.y + 60

facemovement()

crestmovement()

camera.x = me.mid - 259
camera.y = me.y - 259

if camera2.xfollow
then
	if camera2.yfollow
	then
	camera2.x = you.mid - 767
	camera2.y = you.y - 259
	else camera2.x = camera2.x
	camera2.x = you.mid - 767
	camera2.y = camera2.y
	end
else
	if camera2.yfollow
	then
	camera2.y = you.y - 259
	camera2.x = camera2.x
	else
	camera2.x = camera2.x
	camera2.y = camera2.y
end
end

end

function love.draw()

	love.graphics.setScissor(12, 12, 494, 500)
	camera:set()
	love.graphics.draw(enviro.floor, 0, 0)
	love.graphics.setColor(255,255,255)
	love.graphics.draw(you.im, you.xanimate, you.y, 0, you.lr, 1)
	love.graphics.draw(me.im, me.xanimate, me.y, 0, me.lr, 1)
	camera:unset()
	love.graphics.setScissor()

	love.graphics.setScissor(518, 12, 494, 500)
	camera2:set()
	
	love.graphics.draw(enviro.sky, camera2.x + 518, 0)
	love.graphics.draw(enviro.paralax, camera2.x / 2 + 767 / 2, camera2.y / 2 + 513 / 2)
	love.graphics.draw(enviro.floor, 0, 0)
	love.graphics.setColor(255,255,255)
	love.graphics.draw(me.im, me.xanimate, me.y, 0, me.lr, 1)
	love.graphics.draw(you.im, you.xanimate, you.y, 0, you.lr, 1)
	love.graphics.draw(you.face, you.facex, you.facey)
	love.graphics.draw(you.crest, you.crestx, you.cresty)
	armanimate()
	camera2:unset()
	love.graphics.setScissor()


end
