background = love.audio.newSource("sounds/agt.mp3", "static")
background:setVolume(.9)
background:setLooping(true)


bcs = love.audio.newSource("sounds/bigswipe.mp3", "static")
bcs:setVolume(.7)

slowmo = love.audio.newSource("sounds/slowmo.mp3", "static")
slowmo:setVolume(.7)

blues = love.audio.newSource("sounds/blue.mp3", "static")
blues:setVolume(.2)
blues:setPitch(.7)

blues2 = love.audio.newSource("sounds/blue.mp3", "static")
blues2:setVolume(.2)
blues2:setPitch(.7)

blues3 = love.audio.newSource("sounds/blue.mp3", "static")
blues3:setVolume(.2)
blues3:setPitch(.7)

blues4 = love.audio.newSource("sounds/blue.mp3", "static")
blues4:setVolume(.2)
blues4:setPitch(.7)