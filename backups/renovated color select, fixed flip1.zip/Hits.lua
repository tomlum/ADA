--DUDE, MAYBE MAKE ALL BLOCKS SHOULD BE INTEGERS

hitt = {
  me{x = 0, v = 0, j = 0, y = 0, flinch = false, ft = 0, block = 0, dodge = false, invince = false,width = 30, height = 60}
  you{x = 0, v = 0, j = 0, y = 0, flinch = false, ft = 0, block = 0, dodge = false, invince = false, width = 30, height = 60}
}

--the big hit check
function hc(objx, objy, ojx2, objy2, blockable, dir, dodgable,  vee, jay, dam, eff, efftee, xjump, yjump, misc1, misc2)
hitt.me.x = me.x
hitt.me.y = me.y
hitt.me.j = me.j
hitt.me.v = me.v
hitt.me.flinch = me.flinch
hitt.me.ft = me.ft

if not me.block then
  hitt.me.block = 0
else hitt.me
hitt.me.block = me.lr
end

for i,v in ipairs(hitt) do
  
 if (findIntersect(objx,objy,objx2,objy2,v.x,v.y,v.x+v.v+((v.width/2*v.v)/math.abs(v.v)),v.y - v.j + ,true,true) or
 findIntersect(objx,objy,objx2,objy2,v.x,v.y,v.x+v.v,v.y - v.j,true,true))and dodgeable and not v.incince then
v.v = vee
v.j = jay
v.x = v.x + xjump
v.y = v.y - yjump
if v.block and blockable then
v.flinch = eff
v.ft = v.ft + efftee
v.health = v.health - dam
end

end
end
me.x = hitt.me.x
me.y = hitt.me.y
me.y = hitt.me.y
me.j = hitt.me.j
me.v = hitt.me.v
me.flinch = hitt.me.flinch
me.ft = hitt.me.ft
if hitt.me.block ~= 0 then
  me.lr = me.block
  end

end
